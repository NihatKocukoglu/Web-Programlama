﻿using Microsoft.AspNetCore.Mvc;
using FCenter.Services;

namespace FCenter.Controllers
{
    public class ChatController : Controller
    {
        private readonly GeminiService _geminiService;

        public ChatController(GeminiService geminiService)
        {
            _geminiService = geminiService;
        }

        public IActionResult Index()
        {
            // Sisteme "Index yerine Index1 dosyasını aç" diyoruz
            return View("Index1");
        }

        [HttpPost]
        public async Task<IActionResult> Ask(string message, string image)
        {
            // Artık hem mesaj hem de image (base64 string) geliyor
            var response = await _geminiService.GetFitnessAdvice(message, image);
            return Json(new { response = response });
        }
    }
}