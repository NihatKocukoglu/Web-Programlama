using Microsoft.AspNetCore.Mvc;
using FCenter.Data;
using FCenter.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;

namespace FCenter.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        // --- SALON ��LEMLER� (GYM) ---

        [Authorize(Roles = "Admin,Uye")]
        public async Task<IActionResult> Index()
        {
            var gyms = await _context.Gyms.ToListAsync();
            var allTrainers = await _context.Trainers.ToListAsync();

            foreach (var gym in gyms)
            {
                var gymTrainers = allTrainers.Where(t => t.GymName == gym.Name).ToList();
                var autoServices = gymTrainers
                    .Where(t => !string.IsNullOrEmpty(t.Services))
                    .SelectMany(t => t.Services.Split(','))
                    .Select(s => s.Trim())
                    .Where(s => !string.IsNullOrEmpty(s))
                    .Distinct()
                    .ToList();

                if (autoServices.Any())
                {
                    string branchList = string.Join(", ", autoServices);
                    gym.Services = string.IsNullOrEmpty(gym.Services)
                        ? branchList
                        : gym.Services + ", " + branchList;
                }
            }
            return View(gyms ?? new List<Gym>());
        }

        [Authorize(Roles = "Admin,Uye")]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();
            var gym = await _context.Gyms.FirstOrDefaultAsync(m => m.Id == id);
            if (gym == null) return NotFound();

            var trainersInGym = await _context.Trainers.Where(t => t.GymName == gym.Name).ToListAsync();
            ViewBag.Trainers = trainersInGym;
            return View(gym);
        }

        [Authorize(Roles = "Admin")]
        public IActionResult Create() => View();

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Gym gym)
        {
            if (string.IsNullOrEmpty(gym.ServiceDetails)) gym.ServiceDetails = "-";
            ModelState.Remove("ServiceDetails");

            if (ModelState.IsValid)
            {
                _context.Gyms.Add(gym);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(gym);
        }

        // --- ANTREN�R Y�NET�M� ---

        [Authorize(Roles = "Admin,Uye")]
        public async Task<IActionResult> TrainerList()
        {
            return View(await _context.Trainers.ToListAsync());
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> TrainerCreate()
        {
            ViewBag.GymList = await _context.Gyms.ToListAsync();
            ViewBag.BranchList = new List<string> { "Fitness", "Pilates", "Yoga", "Zumba", "Kickboks", "Crossfit", "Y�zme", "Boks" };
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TrainerCreate(Trainer trainer, string[] selectedBranches, decimal TrainerPrice)
        {
            if (selectedBranches != null && selectedBranches.Length > 0)
            {
                trainer.Services = string.Join(", ", selectedBranches);
            }

            ModelState.Remove("Services");
            ModelState.Remove("GymName");

            if (ModelState.IsValid)
            {
                _context.Trainers.Add(trainer);
                await _context.SaveChangesAsync();

                if (selectedBranches != null)
                {
                    foreach (var branch in selectedBranches)
                    {
                        var tService = new TrainerService
                        {
                            TrainerId = trainer.Id,
                            ServiceName = branch,
                            Price = TrainerPrice > 0 ? TrainerPrice : 500,
                            Duration = "60 Dakika"
                        };
                        _context.TrainerServices.Add(tService);
                    }
                    await _context.SaveChangesAsync();
                }

                return RedirectToAction(nameof(TrainerList));
            }

            ViewBag.GymList = await _context.Gyms.ToListAsync();
            ViewBag.BranchList = new List<string> { "Fitness", "Pilates", "Yoga", "Zumba", "Kickboks", "Crossfit", "Y�zme", "Boks" };
            return View(trainer);
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> TrainerDelete(int id)
        {
            var trainer = await _context.Trainers.FindAsync(id);
            if (trainer != null)
            {
                var relatedAppointments = _context.Appointments.Where(a => a.TrainerId == id);
                _context.Appointments.RemoveRange(relatedAppointments);

                var relatedServices = _context.TrainerServices.Where(s => s.TrainerId == id);
                _context.TrainerServices.RemoveRange(relatedServices);

                _context.Trainers.Remove(trainer);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(TrainerList));
        }

        // --- RANDEVU S�STEM� (F�YAT DESTEKL� & ONAY MEKAN�ZMALI) ---

        [Authorize(Roles = "Uye,Admin")]
        public async Task<IActionResult> MakeAppointment(int trainerId)
        {
            var trainer = await _context.Trainers
                .Include(t => t.TrainerServices)
                .FirstOrDefaultAsync(t => t.Id == trainerId);

            if (trainer == null) return NotFound();

            var model = new Appointment
            {
                TrainerId = trainerId,
                Trainer = trainer,
                MemberEmail = User.Identity.Name,
                AppointmentDate = DateTime.Now.AddDays(1),
                Status = "Onay Bekliyor"
            };

            ViewBag.Services = trainer.TrainerServices?.ToList() ?? new List<TrainerService>();
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Uye,Admin")]
        public async Task<IActionResult> MakeAppointment(Appointment appointment)
        {
            // Navigasyon property'lerini validasyondan muaf tutuyoruz
            ModelState.Remove("Trainer");
            ModelState.Remove("TrainerService");
            ModelState.Remove("MemberEmail");
            ModelState.Remove("Status");

            if (ModelState.IsValid)
            {
                // KR�T�K: EF Core'un yeni bir TrainerService nesnesi olu�turmaya 
                // �al���p "Id1" hatas� vermesini engellemek i�in nesneyi null yap�yoruz.
                // Sadece TrainerServiceId (FK) de�erini kullanacak.
                appointment.TrainerService = null;
                appointment.Trainer = null;

                appointment.MemberEmail = User.Identity.Name;
                appointment.Status = "Onay Bekliyor";

                _context.Appointments.Add(appointment);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(MyAppointments));
            }

            var trainer = await _context.Trainers
                .Include(t => t.TrainerServices)
                .FirstOrDefaultAsync(t => t.Id == appointment.TrainerId);

            ViewBag.Services = trainer?.TrainerServices.ToList();
            appointment.Trainer = trainer;
            return View(appointment);
        }

        [Authorize(Roles = "Uye,Admin")]
        public async Task<IActionResult> MyAppointments()
        {
            var userEmail = User.Identity.Name;
            return View(await _context.Appointments
                .Include(a => a.Trainer)
                .Include(a => a.TrainerService)
                .Where(a => a.MemberEmail == userEmail)
                .OrderByDescending(a => a.AppointmentDate)
                .ToListAsync());
        }

        // ADMIN: T�m randevular� listeler
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> ManageAppointments()
        {
            var appointments = await _context.Appointments
                .Include(a => a.Trainer)
                .Include(a => a.TrainerService)
                .OrderByDescending(a => a.Status == "Onay Bekliyor")
                .ThenBy(a => a.AppointmentDate)
                .ToListAsync();
            return View(appointments);
        }

        // ADMIN: Randevu durumunu g�nceller (Onayla/Reddet)
        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApproveAppointment(int id, string status)
        {
            var appointment = await _context.Appointments.FindAsync(id);
            if (appointment == null) return NotFound();

            appointment.Status = status;
            await _context.SaveChangesAsync();

            TempData["AdminMessage"] = $"Randevu ba�ar�yla {status.ToLower()}.";
            return RedirectToAction(nameof(ManageAppointments));
        }
    }
}