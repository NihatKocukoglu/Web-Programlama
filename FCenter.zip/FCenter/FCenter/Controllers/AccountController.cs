﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
using System.Collections.Generic;
using System.Threading.Tasks;
using FCenter.Data; // Veritabanı context'i için
using FCenter.Models; // User modelinizin bulunduğu yer
using System.Linq;

namespace FCenter.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;

        // Constructor: Veritabanını controller'a tanıtıyoruz
        public AccountController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        public async Task<IActionResult> Login(string username, string password)
        {
            var claims = new List<Claim>();

            // 1. ADIM: Admin Girişi (Ödev kuralı olduğu için sabit kalabilir)
            if (username == "ogrencinumarasi@sakarya.edu.tr" && password == "sau")
            {
                claims.Add(new Claim(ClaimTypes.Name, username));
                claims.Add(new Claim(ClaimTypes.Role, "Admin"));
            }
            else
            {
                // 2. ADIM: Gerçek Veritabanı Kontrolü
                // Senin paylaştığın o kritik satır burada veritabanını sorguluyor:
                var user = _context.Users.FirstOrDefault(u => u.UserName == username && u.Password == password);

                if (user != null)
                {
                    claims.Add(new Claim(System.Security.Claims.ClaimTypes.Name, user.UserName ?? "Kullanıcı"));
                    claims.Add(new Claim(ClaimTypes.Role, "Uye"));
                }
                else
                {
                    ViewBag.Error = "Kullanıcı adı veya şifre hatalı!";
                    return View();
                }
            }

            var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var authProperties = new AuthenticationProperties { IsPersistent = true };

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(claimsIdentity),
                authProperties);

            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        public async Task<IActionResult> Register(string username, string email, string password, string confirmPassword)
        {
            if (password != confirmPassword)
            {
                ViewBag.Error = "Girdiğiniz şifreler birbiriyle eşleşmiyor!";
                return View();
            }

            // GÜNCELLEME: Veritabanına gerçekten kayıt ekleme işlemi
            // Eğer veritabanına eklemezsek Login kısmında kullanıcıyı bulamayız.
            var newUser = new User
            {
                UserName = username,
                Email = email,
                Password = password
            };

            _context.Users.Add(newUser);
            await _context.SaveChangesAsync(); // Değişiklikleri SQL'e gönderir

            TempData["SuccessMessage"] = "Kaydınız tamamlandı! Artık kendi şifrenizle giriş yapabilirsiniz.";
            return RedirectToAction("Login");
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            if (HttpContext.Session != null) HttpContext.Session.Clear();
            return RedirectToAction("Login", "Account");
        }
    }
}