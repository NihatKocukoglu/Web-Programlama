﻿using Microsoft.EntityFrameworkCore;
using FCenter.Models;

namespace FCenter.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        // Salon Bilgileri
        public DbSet<Gym> Gyms { get; set; }

        // Eğitmen Bilgileri
        public DbSet<Trainer> Trainers { get; set; }

        // Eğitmen Hizmetleri ve Ücretleri
        public DbSet<TrainerService> TrainerServices { get; set; }

        // Randevular
        public DbSet<Appointment> Appointments { get; set; }

        // Kullanıcılar
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Cascade Path Hatasını Önleme:
            // Bir TrainerService (Hizmet) silindiğinde, ona bağlı randevuların 
            // otomatik silinmesini engelleyerek döngüsel hatayı çözüyoruz.
            modelBuilder.Entity<Appointment>()
                .HasOne(a => a.TrainerService)
                .WithMany()
                .HasForeignKey(a => a.TrainerServiceId)
                .OnDelete(DeleteBehavior.Restrict); // Veya NoAction

            // Aynı şekilde Trainer silindiğinde de randevuları korumaya alıyoruz
            modelBuilder.Entity<Appointment>()
                .HasOne(a => a.Trainer)
                .WithMany()
                .HasForeignKey(a => a.TrainerId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}