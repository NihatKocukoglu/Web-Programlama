﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace FCenter.Services
{
    public class GeminiService
    {
        // Groq API Key
        private readonly string _apiKey = "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";
        private readonly HttpClient _httpClient;

        public GeminiService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<string> GetFitnessAdvice(string userMessage, string base64Image = null)
        {
            try
            {
                var url = "https://api.groq.com/openai/v1/chat/completions";

                // GÜNCELLEME: Sitedeki resmi öneriye göre model isimleri değiştirildi
                var modelName = string.IsNullOrEmpty(base64Image)
                                ? "llama-3.3-70b-versatile"
                                : "meta-llama/llama-4-scout-17b-16e-instruct";

                // Mesaj yapısını oluşturuyoruz
                var messages = new List<object>();
                messages.Add(new { role = "system", content = "Sen profesyonel bir fitness hocasısın. Görüntüleri analiz edip beslenme ve spor tavsiyeleri verirsin." });

                if (string.IsNullOrEmpty(base64Image))
                {
                    // Sadece metin gönderimi
                    messages.Add(new { role = "user", content = userMessage ?? "Merhaba" });
                }
                else
                {
                    // Metin + Resim gönderimi (Llama 4 formatı)
                    messages.Add(new
                    {
                        role = "user",
                        content = new object[] {
                            new { type = "text", text = userMessage ?? "Bu resmi analiz et." },
                            new {
                                type = "image_url",
                                image_url = new { url = $"data:image/jpeg;base64,{base64Image}" }
                            }
                        }
                    });
                }

                var requestBody = new
                {
                    model = modelName,
                    messages = messages.ToArray(),
                    temperature = 0.7
                };

                // Request Ayarları
                _httpClient.DefaultRequestHeaders.Clear();
                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _apiKey);

                var jsonRequest = JsonSerializer.Serialize(requestBody);
                var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync(url, content);
                var responseString = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    return $"AI Hatası: {response.StatusCode}. Detay: {responseString}";
                }

                // Yanıtı parse et
                using var doc = JsonDocument.Parse(responseString);
                return doc.RootElement
                          .GetProperty("choices")[0]
                          .GetProperty("message")
                          .GetProperty("content")
                          .GetString();
            }
            catch (Exception ex)
            {
                return $"Sistem hatası: {ex.Message}";
            }
        }
    }
}