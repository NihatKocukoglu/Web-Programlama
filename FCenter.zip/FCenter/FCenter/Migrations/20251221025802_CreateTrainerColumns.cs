﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FCenter.Migrations
{
    /// <inheritdoc />
    public partial class CreateTrainerColumns : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Trainers_Gyms_GymId",
                table: "Trainers");

            migrationBuilder.DropIndex(
                name: "IX_Trainers_GymId",
                table: "Trainers");

            migrationBuilder.DropColumn(
                name: "GymId",
                table: "Trainers");

            migrationBuilder.RenameColumn(
                name: "FullName",
                table: "Trainers",
                newName: "Services");

            migrationBuilder.RenameColumn(
                name: "Bio",
                table: "Trainers",
                newName: "Name");

            migrationBuilder.AddColumn<string>(
                name: "Availability",
                table: "Trainers",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "GymName",
                table: "Trainers",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Availability",
                table: "Trainers");

            migrationBuilder.DropColumn(
                name: "GymName",
                table: "Trainers");

            migrationBuilder.RenameColumn(
                name: "Services",
                table: "Trainers",
                newName: "FullName");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "Trainers",
                newName: "Bio");

            migrationBuilder.AddColumn<int>(
                name: "GymId",
                table: "Trainers",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Trainers_GymId",
                table: "Trainers",
                column: "GymId");

            migrationBuilder.AddForeignKey(
                name: "FK_Trainers_Gyms_GymId",
                table: "Trainers",
                column: "GymId",
                principalTable: "Gyms",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
