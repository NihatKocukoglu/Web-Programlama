﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FCenter.Migrations
{
    /// <inheritdoc />
    public partial class UpdateGymDetails : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "PhoneNumber",
                table: "Gyms",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ServiceDetails",
                table: "Gyms",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Services",
                table: "Gyms",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PhoneNumber",
                table: "Gyms");

            migrationBuilder.DropColumn(
                name: "ServiceDetails",
                table: "Gyms");

            migrationBuilder.DropColumn(
                name: "Services",
                table: "Gyms");
        }
    }
}
