﻿using System.ComponentModel.DataAnnotations;

namespace FCenter.Models
{
    public class Trainer
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Antrenör adı zorunludur.")]
        [Display(Name = "Ad Soyad")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Uzmanlık alanı belirtilmelidir.")]
        [Display(Name = "Uzmanlık Alanları")]
        public string Specialization { get; set; } // Örn: Kas Geliştirme, Kilo Verme

        [Required(ErrorMessage = "Hizmet türleri belirtilmelidir.")]
        [Display(Name = "Verdiği Hizmetler")]
        public string Services { get; set; } // Örn: Pilates, Crossfit

        [Required(ErrorMessage = "Müsaitlik saatleri belirtilmelidir.")]
        [Display(Name = "Müsaitlik Saatleri")]
        public string Availability { get; set; } // Örn: Pazartesi 09:00-12:00, Çarşamba 15:00-18:00

        // Hangi salonda çalıştığını belirtmek için (İsteğe bağlı ama önerilir)
        [Display(Name = "Çalıştığı Salon")]
        public string GymName { get; set; }

        // Models/Trainer.cs içine eklenecek
        public virtual ICollection<TrainerService> TrainerServices { get; set; } = new List<TrainerService>();
    }
}