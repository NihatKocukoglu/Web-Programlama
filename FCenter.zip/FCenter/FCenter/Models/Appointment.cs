﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FCenter.Models
{
    public class Appointment
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string MemberEmail { get; set; } // Randevu alan üyenin emaili

        // --- ANTRENÖR İLİŞKİSİ ---
        [Required]
        public int TrainerId { get; set; }

        [ForeignKey("TrainerId")] // EF Core'un TrainerId1 oluşturmasını engeller
        public virtual Trainer? Trainer { get; set; }

        // --- HİZMET VE ÜCRET İLİŞKİSİ ---
        [Required(ErrorMessage = "Lütfen bir hizmet seçiniz.")]
        public int TrainerServiceId { get; set; }

        [ForeignKey("TrainerServiceId")] // EF Core'un TrainerServiceId1 oluşturmasını engeller
        public virtual TrainerService? TrainerService { get; set; }

        // --- TARİH VE SAAT ---
        [Required(ErrorMessage = "Lütfen bir tarih seçiniz.")]
        [Display(Name = "Randevu Tarihi")]
        [DataType(DataType.Date)]
        public DateTime AppointmentDate { get; set; }

        [Required(ErrorMessage = "Lütfen saat seçiniz.")]
        [Display(Name = "Randevu Saati")]
        public string AppointmentTime { get; set; } // Örn: "10:00 - 11:00"

        // --- ONAY MEKANİZMASI ---
        [Display(Name = "Durum")]
        public string Status { get; set; } = "Onay Bekliyor";
    }
}