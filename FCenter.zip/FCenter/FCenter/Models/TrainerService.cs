﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FCenter.Models
{
    public class TrainerService
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Hizmet adı zorunludur.")]
        [Display(Name = "Hizmet Adı")]
        public string ServiceName { get; set; } = string.Empty; // Örn: Reformer Pilates, Kickboks

        [Required(ErrorMessage = "Ücret alanı zorunludur.")]
        [Column(TypeName = "decimal(18,2)")]
        [Range(0.01, 10000.00, ErrorMessage = "Ücret 0'dan büyük olmalıdır.")]
        [Display(Name = "Ders Ücreti")]
        public decimal Price { get; set; }

        [Display(Name = "Süre")]
        public string Duration { get; set; } = "60 Dakika";

        // --- İLİŞKİLER ---

        [Required]
        public int TrainerId { get; set; }

        [ForeignKey("TrainerId")]
        public virtual Trainer? Trainer { get; set; }

        // İlişki karmaşasını önlemek için InverseProperty veya net tanımlama
        // Bu sayede Appointment tablosundaki TrainerServiceId ile tam eşleşir
        [InverseProperty("TrainerService")]
        public virtual ICollection<Appointment> Appointments { get; set; } = new List<Appointment>();
    }
}