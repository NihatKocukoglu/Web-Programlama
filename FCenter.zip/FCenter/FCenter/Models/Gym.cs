﻿using System.ComponentModel.DataAnnotations;

namespace FCenter.Models
{
    public class Gym
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Spor salonu adı boş bırakılamaz.")]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Salon adı 3 ile 100 karakter arasında olmalıdır.")]
        [Display(Name = "Salon Adı")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Adres bilgisi zorunludur.")]
        [MinLength(10, ErrorMessage = "Adres en az 10 karakter olmalıdır.")]
        [Display(Name = "Adres")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Çalışma saatleri zorunludur.")]
        [Display(Name = "Çalışma Saatleri")]
        public string WorkingHours { get; set; }

        [Required(ErrorMessage = "En az bir hizmet belirtmelisiniz.")]
        [Display(Name = "Sunulan Hizmetler")]
        public string Services { get; set; } // Örn: Fitness, Yoga, Pilates

        [Required(ErrorMessage = "Hizmet süre ve ücret detayları zorunludur.")]
        [Display(Name = "Ücret ve Süre Detayları")]
        [DataType(DataType.MultilineText)]
        public string? ServiceDetails { get; set; } // Örn: Yoga: 60dk - 200TL

        [Display(Name = "İletişim Numarası")]
        [Phone(ErrorMessage = "Geçerli bir telefon numarası giriniz.")]
        public string PhoneNumber { get; set; }
    }
}