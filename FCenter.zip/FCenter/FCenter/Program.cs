using Microsoft.EntityFrameworkCore;
using FCenter.Data;
using Microsoft.AspNetCore.Authentication.Cookies;
using FCenter.Services;

var builder = WebApplication.CreateBuilder(args);

// 1. Veritaban� Ba�lant�s�
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));

// --- G�NCELLEME: Session (Oturum) Servisi Eklendi ---
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // 30 dakika hareketsizlikten sonra oturum d��er
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// 2. Kimlik Do�rulama (Authentication) Servisi
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.LogoutPath = "/Account/Logout";
        options.AccessDeniedPath = "/Account/AccessDenied";
    });

// 3. YAPAY ZEKA VE SERV�S KAYITLARI
builder.Services.AddHttpClient<GeminiService>();

// 4. Controller ve View Servisleri
builder.Services.AddControllersWithViews()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
    });

var app = builder.Build();

// 5. HTTP �stek Hatt� (Middleware) Yap�land�rmas�
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// --- G�NCELLEME: Session Kullan�m� Etkinle�tirildi ---
app.UseSession(); // Bu sat�r Authentication'dan �nce olmal�d�r.

// --- G�venlik S�ralamas� ---
app.UseAuthentication();
app.UseAuthorization();
// ---------------------------

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();